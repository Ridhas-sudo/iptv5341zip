# IPTV Android App Fix Project

Ce projet contient la structure complète du code Kotlin d'une application IPTV Android corrigée du bug de nullabilité dans `IptvViewModel.kt`.

## Problème résolu
Dans `IptvViewModel.kt`, la méthode `extractHostAndPort` attendait une variable de type `String` non nulle, alors que `currentPlayingStreamUrl` ou `targetStreamUrl` étaient de type `String?`.

La vérification stricte de non-nullité a été ajoutée pour garantir une compilation réussie sur GitHub Actions sans erreurs de build Kotlin.
