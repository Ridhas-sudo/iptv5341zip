package com.example.iptv.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URI

enum class StreamStatus {
    UNKNOWN,
    ONLINE,
    OFFLINE
}

class IptvViewModel : ViewModel() {

    private val _streamStatus = MutableStateFlow(StreamStatus.UNKNOWN)
    val streamStatus: StateFlow<StreamStatus> = _streamStatus

    var currentPlayingStreamUrl: String? = null

    /**
     * Vérifie le statut d'un flux IPTV en testant l'ouverture de son hôte et de son port.
     */
    fun checkStreamStatus(targetStreamUrl: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            val streamUrl = currentPlayingStreamUrl ?: targetStreamUrl
            if (streamUrl != null && streamUrl.isNotBlank()) {
                val (host, port) = extractHostAndPort(streamUrl)
                if (host.isNotEmpty()) {
                    val isPortOpen = isPortOpen(host, port)
                    _streamStatus.value = if (isPortOpen) StreamStatus.ONLINE else StreamStatus.OFFLINE
                } else {
                    _streamStatus.value = StreamStatus.OFFLINE
                }
            } else {
                _streamStatus.value = StreamStatus.OFFLINE
            }
        }
    }

    private fun extractHostAndPort(url: String): Pair<String, Int> {
        return try {
            val uri = URI(url)
            val host = uri.host ?: ""
            val port = if (uri.port != -1) uri.port else if (uri.scheme == "https") 443 else 80
            Pair(host, port)
        } catch (e: Exception) {
            Pair("", 80)
        }
    }

    private fun isPortOpen(host: String, port: Int, timeout: Int = 3000): Boolean {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), timeout)
                true
            }
        } catch (e: Exception) {
            false
        }
    }
}
