package com.example.iptv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.iptv.ui.IptvViewModel
import com.example.iptv.ui.StreamStatus

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    IptvScreen()
                }
            }
        }
    }
}

@Composable
fun IptvScreen(viewModel: IptvViewModel = viewModel()) {
    val streamStatus by viewModel.streamStatus.collectAsState()
    var urlInput by remember { mutableStateOf("http://example.com:8080/live/test.m3u8") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "IPTV Stream Checker", style = MaterialTheme.typography.headlineMedium)
        
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = urlInput,
            onValueChange = { urlInput = it },
            label = { Text("Stream URL") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = { viewModel.checkStreamStatus(urlInput) }) {
            Text("Vérifier le flux")
        }

        Spacer(modifier = Modifier.height(24.dp))

        val statusText = when (streamStatus) {
            StreamStatus.UNKNOWN -> "Statut : Non vérifié"
            StreamStatus.ONLINE -> "Statut : EN LIGNE (Online)"
            StreamStatus.OFFLINE -> "Statut : HORS LIGNE (Offline)"
        }

        Text(text = statusText, style = MaterialTheme.typography.titleMedium)
    }
}
